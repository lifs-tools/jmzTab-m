# SpectraRef

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ms_run** | [**MsRun**](MsRun.md) | The ms run object reference by this spectral reference.  | 
**reference** | **str** | The (vendor-dependendent) reference string to the actual mass spectrum.  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


