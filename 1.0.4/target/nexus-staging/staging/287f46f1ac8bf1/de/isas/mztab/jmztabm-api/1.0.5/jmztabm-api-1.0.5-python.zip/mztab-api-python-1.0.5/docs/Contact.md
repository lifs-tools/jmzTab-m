# Contact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | The contact&#39;s name. | [optional] 
**affiliation** | **str** | The contact&#39;s affiliation. | [optional] 
**email** | **str** | The contact&#39;s e-mail address. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


