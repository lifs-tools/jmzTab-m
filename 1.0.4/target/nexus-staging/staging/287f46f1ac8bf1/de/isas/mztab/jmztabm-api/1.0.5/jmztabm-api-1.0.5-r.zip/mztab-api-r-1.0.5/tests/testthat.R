library(testthat)
library(rmztab)

test_check("rmztab")
