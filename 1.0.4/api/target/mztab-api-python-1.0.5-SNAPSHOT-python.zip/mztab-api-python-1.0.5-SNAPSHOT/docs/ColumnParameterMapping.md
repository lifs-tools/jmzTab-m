# ColumnParameterMapping

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**column_name** | **str** | The fully qualified target column name. | 
**param** | [**Parameter**](Parameter.md) | The parameter specifying the unit. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


