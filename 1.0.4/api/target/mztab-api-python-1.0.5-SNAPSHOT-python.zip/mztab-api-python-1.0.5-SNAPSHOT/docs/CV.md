# CV

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **str** | The abbreviated CV label. | 
**full_name** | **str** | The full name of this CV, for humans. | 
**version** | **str** | The CV version used when the file was generated. | 
**uri** | **str** | A URI to the CV definition. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


