# Publication

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**publication_items** | [**list[PublicationItem]**](PublicationItem.md) | The publication item ids referenced by this publication. | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


